import cv2
cap = cv2.VideoCapture(0)
image = cv2.imread('background1.jpg.jpg')
image1 = cv2.imread('background2.jpg')
image2 = cv2.imread('background3.jpg')
image3 = cv2.imread('background4.jpg')
image4 = cv2.imread('background5.jpg')

while True:
    flag, frame = cap.read()
    if not flag:
        print("cloudn't access camera")
        break
    image = cv2.resize(image, (frame.shape[1], frame.shape[0]))
    image1 = cv2.resize(image1, (frame.shape[1], frame.shape[0]))
    image2 = cv2.resize(image2, (frame.shape[1], frame.shape[0]))
    image3 = cv2.resize(image3, (frame.shape[1], frame.shape[0]))
    image4 = cv2.resize(image4, (frame.shape[1], frame.shape[0]))

    blend1 = cv2.addWeighted(image, 0.2, frame, 0.9, gamma=0.2)
    blend2 = cv2.addWeighted(image1, 0.2, frame, 0.9, gamma=0.2)
    blend3 = cv2.addWeighted(image2, 0.2, frame, 0.9, gamma=0.2)
    blend4 = cv2.addWeighted(image3, 0.2, frame, 0.9, gamma=0.2)
    blend5 = cv2.addWeighted(image4, 0.2, frame, 0.9, gamma=0.2)

    cv2.imshow("blend", blend1)
    cv2.imshow("blend", blend2)
    cv2.imshow("blend", blend3)
    cv2.imshow("blend", blend4)
    cv2.imshow("blend", blend5)

    if cv2.waitKey(10) & 0xff == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()